﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AtividadeDotNet.DTO.RemoverSapato
{
    public class RemoverSapatoResponse
    {
        public string msg { get; set; }
    }
}
